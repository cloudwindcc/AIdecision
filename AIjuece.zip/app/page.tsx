import { ChatInterface } from '@/components/ChatInterface'

export default function Home() {
  return <ChatInterface />
}